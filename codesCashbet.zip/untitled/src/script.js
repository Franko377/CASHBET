// script.js

let currentMultiplier = 1.00;
let betAmount = 0;
let balance = 1000;
let roundActive = false;
let intervalId;

// DOM Elements
const multiplierDisplay = document.getElementById('multiplier');
const startGameButton = document.getElementById('start-game');
const cashOutButton = document.getElementById('cash-out');
const placeBetButton = document.getElementById('place-bet');
const betInput = document.getElementById('bet-amount');
const statusMessage = document.getElementById('status-message');
const balanceDisplay = document.getElementById('balance');
const plane = document.getElementById('plane');
const depositButton = document.getElementById('deposit-btn');
const withdrawButton = document.getElementById('withdraw-btn');
const signUpButton = document.getElementById('sign-up-btn');
const logInButton = document.getElementById('log-in-btn');

// Modal Elements
const signUpModal = document.getElementById('sign-up-modal');
const closeModalButton = document.querySelector('.close');
const step1 = document.getElementById('step-1');
const step2 = document.getElementById('step-2');
const submitDetailsButton = document.getElementById('submit-details');
const verifyCodeButton = document.getElementById('verify-code');

// Function to update the balance display
function updateBalance(amount) {
    balance += amount;
    balanceDisplay.textContent = balance.toFixed(2);
}

// Show Sign Up Modal
signUpButton.addEventListener('click', () => {
    signUpModal.style.display = 'block';
});

// Close Sign Up Modal
closeModalButton.addEventListener('click', () => {
    signUpModal.style.display = 'none';
    step1.style.display = 'block'; // Reset to step 1
    step2.style.display = 'none';
});

// Handle Step 1 Submission
submitDetailsButton.addEventListener('click', () => {